
"filtered_data" contains summaries collected from undergraduate and master's students enrolled in an Advanced Computer Science course.

The file stucture is:

--filtered_data
    --midterm_1_notes_on_campus
        --submission_94647691
        ...

    --midterm_1_notes_MCIT_online
        --submission_94038641
        ...

    --midterm_2_notes_MCIT_online
        --submission_105107923
        ...

    --midterm_2_notes_on_campus
        --submission_103620351
        ...

 Each submission folder contains a summary from a student. 
 